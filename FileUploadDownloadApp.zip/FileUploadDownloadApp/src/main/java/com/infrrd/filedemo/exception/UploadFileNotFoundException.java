package com.infrrd.filedemo.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class UploadFileNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UploadFileNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public UploadFileNotFoundException(String message) {
		super(message);
	}
	

}
